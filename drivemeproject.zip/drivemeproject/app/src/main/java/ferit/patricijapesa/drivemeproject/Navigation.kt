package ferit.patricijapesa.drivemeproject

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navigation
import ferit.patricijapesa.drivemeproject.models.DriveViewModel

object Routes {
    const val SCREEN_ALL_DRIVES = "driveList"
    const val SCREEN_DRIVE_DETAILS = "driveDetails/{driveId}"
    const val SCREEN_USER_DETAILS = "userDetails/{userId}"
    const val SCREEN_SEARCH_RESULTS = "searchList/{searchInput}"
    const val SCREEN_NEW_DRIVE = "newDrive/{driveId}"
    fun getDriveDetailsPath(driveId: Int?) : String {
        if (driveId != null && driveId != -1) {
           return "driveDetails/$driveId"
        }
        return "driveDetails/0"
    }
    fun getUserDetailsPath(userId: Int?) : String {
        if (userId != null && userId != -1) {
            return "userDetails/$userId"
        }
        return "userDetails/0"
    }
    fun getSearchPath(searchInput: String?) : String {
        if (searchInput != null) {
            return "searchList/$searchInput"
        }
        return "searchList/0"
    }
    fun getNewDrivePath(driveId: Int?) : String {
        if (driveId != null && driveId != -1) {
            return "newDrive/$driveId"
        }
        return "newDrive/0"
    }
}

@Composable
fun NavigationController (
    viewModel: DriveViewModel
) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.SCREEN_ALL_DRIVES){
        composable(Routes.SCREEN_ALL_DRIVES) {
            MainScreen (
                viewModel = viewModel,
                navigation = navController
            )
        }
        composable(
            Routes.SCREEN_NEW_DRIVE,
            arguments = listOf(
                navArgument("driveId") {
                    type = NavType.IntType
                }
            )
        ) {
            backStackEntry ->
            backStackEntry.arguments?.getInt("driveId")?.let {
                NewDriveScreen (
                    viewModel = viewModel,
                    navigation = navController
                )
            }
        }

        composable(
            Routes.SCREEN_SEARCH_RESULTS,
            arguments = listOf(navArgument("searchInput") { })
        ) {
            backStackEntry ->
            backStackEntry.arguments?.getString("searchInput")?.let {
                SearchResults (
                    viewModel = viewModel,
                    navigation = navController,
                    query = it
                )
            }
        }

        composable(
            Routes.SCREEN_DRIVE_DETAILS,
            arguments = listOf(
                navArgument("driveId") {
                    type = NavType.IntType
                }
            )
        ) {
            backStackEntry ->
            backStackEntry.arguments?.getInt("driveId")?.let {
                DriveScreen (
                    viewModel = viewModel,
                    navigation = navController,
                    driveId = it
                )
            }
        }

        composable(
            Routes.SCREEN_USER_DETAILS,
            arguments = listOf(
                navArgument("userId") {
                    type = NavType.IntType
                }
            )
        ) {
            backStackEntry ->
            val userId = backStackEntry.arguments?.getInt("userId")
            if (userId != null) {
                UserScreen (
                    viewModel = viewModel,
                    navigation = navController
                )
            }
        }
    }
}






