package ferit.patricijapesa.drivemeproject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import ferit.patricijapesa.drivemeproject.models.DriveViewModel
import ferit.patricijapesa.drivemeproject.ui.theme.DrivemeprojectTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val viewModel by viewModels<DriveViewModel>()
        setContent {
            DrivemeprojectTheme {
                NavigationController(viewModel)
            }
        }
    }
}

