package ferit.patricijapesa.drivemeproject.models

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.ViewModel
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.toObject

class DriveViewModel : ViewModel() {
    private val db = Firebase.firestore
    var drivesData = mutableStateListOf<Drive>()
    val usersData = mutableStateListOf<User>()
    init {
        fetchDatabaseData()
    }
    private fun fetchDatabaseData() {
        db.collection("drives")
            .get()
            .addOnSuccessListener {
                result ->
                for (data in result.documents) {
                    val drive = data.toObject(Drive::class.java)
                    if (drive != null) {
                        drive.driveId = data.id
                        drivesData.add(drive)
                    }
                }
            }

        db.collection("users")
            .get()
            .addOnSuccessListener { result ->
                for (data in result.documents) {
                    val user = data.toObject(User::class.java)
                    if (user != null) {
                        user.userId = data.id
                        usersData.add(user)
                    }
                }
            }
    }


    fun updateDrive(drive: Drive) {
        db.collection("drives")
            .document(drive.driveId)
            .set(drive)
    }

    fun addDrive(destination: String, departure: String, totalSeats: Int) {
        val newDrive = Drive(
            driveId = drivesData.size.toString(),
            destination = destination,
            departure = departure,
            totalSeats = totalSeats,
            image = "https://via.placeholder.com/150"
        )
        drivesData = (drivesData + newDrive) as SnapshotStateList<Drive>
    }
}