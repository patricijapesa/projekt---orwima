package ferit.patricijapesa.drivemeproject

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import androidx.navigation.NavController
import ferit.patricijapesa.drivemeproject.models.Drive
import ferit.patricijapesa.drivemeproject.models.DriveViewModel
import ferit.patricijapesa.drivemeproject.ui.theme.Purple40
import ferit.patricijapesa.drivemeproject.ui.theme.PurpleGrey80

@Composable
fun DriveScreen (
    viewModel: DriveViewModel,
    navigation: NavController,
    driveId: Int
) {
    val scrollState = rememberLazyListState()
    val drive = viewModel.drivesData[driveId]
    LazyColumn(
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally,
        state = scrollState,
        modifier = Modifier
            .fillMaxSize()
            .background(PurpleGrey80)
    ) {
        item {
            ImageAndTitle(viewModel = viewModel, navigation = navigation, drive = drive)
            Buttons(driveId = driveId, viewModel = viewModel)
        }
    }
}

@Composable
fun IconButton(
    @DrawableRes iconResource: Int,
    color: Color,
    elevation: ButtonElevation? =
        ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
    onClick: () -> Unit = {}
) {
    Button(
        contentPadding = PaddingValues(),
        elevation = elevation,
        onClick = { onClick() },
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent,
            contentColor = color),
        shape = RoundedCornerShape(5.dp),
        modifier = Modifier
            .width(38.dp)
            .height(38.dp)
    ) {
        Icon(
            painter = painterResource(id = iconResource),
            contentDescription = null
        )
    }
}

@Composable
fun ImageAndTitle(
    viewModel: DriveViewModel,
    navigation: NavController,
    drive: Drive
) {
    Box(
        modifier = Modifier.height(250.dp)
    ) {
        Image(
            painter = rememberAsyncImagePainter(model = drive.image),
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .clip(shape = RoundedCornerShape(0.dp, 0.dp, 20.dp, 20.dp)),
            contentScale = ContentScale.Crop
        )
        Row {
            IconButton(R.drawable.arrow_back, Color.White) {
                navigation.popBackStack(
                    Routes.SCREEN_ALL_DRIVES,
                    false
                )
            }
        }
    }
    Spacer(modifier = Modifier.height(15.dp))
    Text(
        text = drive.destination,
        fontSize = 45.sp,
        color = Purple40,
        modifier = Modifier.padding(20.dp)
    )
    Spacer(modifier = Modifier.height(5.dp))
}


@Composable
fun ChoiceButton(text:String,
                 isActive: Boolean,
                 onClick: () -> Unit){
    Button(shape = RoundedCornerShape(13.dp),
        elevation = null,
        colors = if (isActive) ButtonDefaults.buttonColors(contentColor = Color.White, containerColor = Color.DarkGray) else
            ButtonDefaults.buttonColors(contentColor = Color.White, containerColor = Purple40),
        onClick = { onClick() }
    ){
        Text(text,
            fontSize=14.sp,)
    }
}

@Composable
fun Buttons(
    driveId: Int,
    viewModel: DriveViewModel
) {
    val drive = viewModel.drivesData[driveId]
    var currentActiveButton by remember { mutableStateOf(0) }
    Row(
        horizontalArrangement = Arrangement.SpaceAround,
        modifier = Modifier
            .padding(horizontal = 15.dp, vertical = 5.dp)
            .background(Color.Transparent)
            .fillMaxWidth()
    ) {
        ChoiceButton(
            text = "Departure",
            isActive = currentActiveButton == 0,
            ) {
            currentActiveButton = 0
        }
        Spacer(modifier = Modifier.width(25.dp))
        ChoiceButton(
            text = "Price",
            isActive = currentActiveButton == 1,
            ){
            currentActiveButton = 1
        }
        Spacer(modifier = Modifier.width(25.dp))
        ChoiceButton(
            text="TotalSeats",
            isActive=currentActiveButton == 2)
        {
            currentActiveButton = 2
        }
    }
    Spacer(modifier = Modifier.height(25.dp))
    when (currentActiveButton) {
        0 -> DriveDeparture(text = drive.departure)
        1 -> DrivePrice(text = drive.price)
        2 -> TotalSeats(text = drive.totalSeats.toString())
    }
}

@Composable
fun DriveDeparture(text:String) {
    Box(modifier = Modifier
        .fillMaxSize()
        .padding(30.dp)
        .border(BorderStroke(5.dp, Purple40))
        .padding(30.dp)
    ){
        Text(
            text,
            color = Purple40,
            fontSize = 20.sp,
            modifier = Modifier
                .fillMaxSize()
                .align(Alignment.Center)
        )
    }
}

@Composable
fun DrivePrice(text:String) {
    Box(modifier = Modifier
        .fillMaxSize()
        .padding(30.dp)
        .border(BorderStroke(5.dp, Purple40))
        .padding(30.dp)
    ){
        Text(
            text,
            color = Purple40,
            fontSize = 20.sp,
            modifier = Modifier
                .fillMaxSize()
                .align(Alignment.Center)
        )
    }
}

@Composable
fun TotalSeats(text:String) {
    Box(modifier = Modifier
        .fillMaxSize()
        .padding(30.dp)
        .border(BorderStroke(5.dp, Purple40))
        .padding(30.dp)
    ){
        Text(
            text,
            color = Purple40,
            fontSize = 20.sp,
            modifier = Modifier
                .fillMaxSize()
                .align(Alignment.Center)
        )
    }
}



