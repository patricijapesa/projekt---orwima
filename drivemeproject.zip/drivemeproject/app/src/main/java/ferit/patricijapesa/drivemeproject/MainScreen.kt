package ferit.patricijapesa.drivemeproject

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import ferit.patricijapesa.drivemeproject.models.DriveViewModel
import ferit.patricijapesa.drivemeproject.ui.theme.Purple40

@Composable
fun MainScreen(
    viewModel: DriveViewModel,
    navigation: NavController
) {
    var showDialog by remember {
        mutableStateOf(false)
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Purple40)
    ) {
        Column(
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.Start,
            modifier = Modifier.fillMaxSize()
        ) {
            Spacer(modifier = Modifier.height(15.dp))
            SearchBar(viewModel = viewModel, navigation = navigation)
            Greeting()
            Button1(viewModel = viewModel, navigation = navigation)
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.BottomEnd),
            containerColor = Color.White,
            contentColor = Color.Black
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Drive")
        }

        if (showDialog) {
            NewDriveDialog(
                onDismiss = { showDialog = false },
                onSave = { destination, departure, totalSeats ->
                    viewModel.addDrive(destination, departure, totalSeats)
                    showDialog = false
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewDriveDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Int) -> Unit
) {
    var destination by remember { mutableStateOf("") }
    var departure by remember { mutableStateOf("") }
    var totalSeats by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = { onDismiss() },
        title = {
            Text(text = "New Drive")
        },
        text = {
            Column {
                TextField(
                    value = destination,
                    onValueChange = { destination = it },
                    label = { Text("Destination") }
                )
                TextField(
                    value = departure,
                    onValueChange = { departure = it },
                    label = { Text("Departure") }
                )
                TextField(
                    value = totalSeats,
                    onValueChange = { totalSeats = it },
                    label = { Text("Total Seats") },
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(destination, departure, totalSeats.toIntOrNull() ?: 0)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchBar(
    viewModel: DriveViewModel,
    navigation: NavController,
    colors: TextFieldColors = TextFieldDefaults.textFieldColors(
        containerColor = Color.White,
        placeholderColor = Color.DarkGray,
        textColor = Color.LightGray,
        unfocusedLabelColor = Color.DarkGray,
        focusedIndicatorColor = Color.Transparent,
        unfocusedIndicatorColor = Color.Transparent,
        disabledIndicatorColor = Color.Transparent
    )
) {
    var searchInput by remember {
        mutableStateOf("")
    }
    TextField(
        value = searchInput,
        onValueChange = { searchInput = it },
        label = {
            Text("Search drives")
        },
        leadingIcon = {
            IconButton (iconResource = R.drawable.search, color = Color.LightGray){
                navigation.navigate(
                    Routes.getSearchPath(searchInput)
                )
            }
        },
        colors = colors,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

@Composable
fun Greeting() {
    Column(){
        Spacer(modifier = Modifier.height(25.dp))
        Text(
            text = "Welcome",
            fontSize = 60.sp,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier=Modifier.fillMaxWidth()
            )
        Text(
            text = "to",
            fontSize = 60.sp,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier=Modifier.fillMaxWidth()
            )
        Spacer(modifier = Modifier.height(25.dp))
        Text(
            text = "DriveMe",
            fontSize = 60.sp,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier=Modifier.fillMaxWidth()
            )
        Spacer(modifier = Modifier.height(45.dp))
    }
}

@Composable
fun WhiteButton(
    text: String,
    isActive: Boolean,
    onClick: () -> Unit){
    Button(shape = RoundedCornerShape(13.dp),
        elevation = null,
        colors = if (isActive) ButtonDefaults.buttonColors(contentColor = Color.White, containerColor = Color.DarkGray) else
            ButtonDefaults.buttonColors(contentColor = Color.Black, containerColor = Color.White),
        onClick = { onClick() }
    ){
        Text(text, fontSize=14.sp,)
    }
}

@Composable
fun Button1(
    viewModel: DriveViewModel,
    navigation: NavController
) {
    var currentActiveButton by remember { mutableStateOf(0) }
    var currentScreen by remember { mutableStateOf("AllDrives") }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .background(Color.Transparent)
                .fillMaxWidth()
                .height(44.dp)
        ) {
            WhiteButton(
                text = "All drives",
                isActive = currentActiveButton == 0,
            ) {
                currentActiveButton = 0
                currentScreen = "AllDrives"
            }
            Spacer(modifier = Modifier.width(25.dp))
            WhiteButton(
                text = "Most popular users",
                isActive = currentActiveButton == 1,
            ) {
                currentActiveButton = 1
                currentScreen = "MostPopularUsers"
            }
            Spacer(modifier = Modifier.width(25.dp))
        }
        Spacer(modifier = Modifier.height(30.dp))
    }

    when (currentScreen) {
        "AllDrives" -> AllDrives(viewModel = viewModel, navigation = navigation)
        "MostPopularUsers" -> MostPopularUsers(viewModel = viewModel, navigation = navigation)
    }

    Spacer(modifier = Modifier.height(20.dp))
}

@Composable
fun DriveCard(
    title: String,
    image: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(100.dp)
            .height(150.dp)
            .clickable {
                onClick()
            }
        ,
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent,
        )
    ){
        Box(
            modifier= Modifier
                .fillMaxSize()
        ) {
            Image(
                painter = rememberAsyncImagePainter(model = image),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Column(
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
            ) {
                Text(
                    text = title,
                    style= TextStyle(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun UserCard(
    name: String,
    image: String,
    email: String,
    rating: Float
) {
    var showDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .width(100.dp)
            .height(150.dp)
            .clickable { showDialog = true },
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent,
        )
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = rememberAsyncImagePainter(model = image),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Column(
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
            ) {
                Text(
                    text = name,
                    style = TextStyle(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text(text = name)
            },
            text = {
                Column {
                    Text(text = "Email: $email")
                    Text(text = "Rating: $rating")
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("OK")
                }
            }
        )
    }
}


@Composable
fun MostPopularUsers(
    viewModel: DriveViewModel,
    navigation: NavController
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        items(viewModel.usersData.size) {
            UserCard(
                name = viewModel.usersData[it].name,
                image = viewModel.usersData[it].image,
                email = viewModel.usersData[it].email,
                rating = viewModel.usersData[it].rating.toFloat()
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
    }
}

@Composable
fun AllDrives(
    viewModel: DriveViewModel,
    navigation: NavController
) {
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        items(viewModel.drivesData.size) {
            DriveCard(
                title = viewModel.drivesData[it].destination,
                image = viewModel.drivesData[it].image
            ) {
                navigation.navigate(
                    Routes.getDriveDetailsPath(it)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }
    }
}

