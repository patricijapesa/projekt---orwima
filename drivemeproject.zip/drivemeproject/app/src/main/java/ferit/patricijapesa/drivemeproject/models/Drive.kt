package ferit.patricijapesa.drivemeproject.models

data class Drive (
    var driveId: String = "",
    var driverId: String = "",
    val departure: String = "",
    var destination: String = "",
    var totalSeats: Int = 0,
    val bookedSeats: Int = 0,
    val price: String = "",
    val image: String = "",
    var user: User? = null
)
