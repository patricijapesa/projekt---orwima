package ferit.patricijapesa.drivemeproject.models

data class User (
    var userId: String = "",
    val name: String = "",
    val email: String = "",
    val image: String = "",
    val rating: Double = 0.0
)