package ferit.patricijapesa.projekt.models

class Booking (
    val bookingId: String = "",
    val driveId: String = "",
    val userId: String = "",
    val status: String = ""
)