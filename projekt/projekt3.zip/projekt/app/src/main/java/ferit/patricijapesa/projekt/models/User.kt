package ferit.patricijapesa.projekt.models

class User (
    val userId: String = "",
    val name: String = "",
    val email: String = "",
    val profilePic: String = "",
    val rating: Number
)